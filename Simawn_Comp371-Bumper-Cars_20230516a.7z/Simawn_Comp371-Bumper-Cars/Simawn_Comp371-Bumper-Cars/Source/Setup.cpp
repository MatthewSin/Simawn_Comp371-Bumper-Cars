#include <Windows.h>

#include "Setup.h"
#include <string>
#include <iostream>
//#define GLEW_STATIC 1   // This allows linking with Static Library on Windows, without DLL
#include <GL/glew.h>    // Include GLEW - OpenGL Extension Wrangler

#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/common.hpp>

using namespace std;
using namespace glm;

Setup* Setup::instance = 0;
GLFWwindow* Setup::window = 0;
int Setup::SCREEN_WIDTH = 0;
int Setup::SCREEN_HEIGHT = 0;

Setup& Setup::getInstance(int width, int height, string title) {
	if (instance == 0) instance = new Setup(width, height, title);
	return *instance;
}

Setup::Setup(int width, int height, string title) {
	SCREEN_WIDTH = width;
	SCREEN_HEIGHT = height;

	// Initialize GLFW and OpenGL version
	glfwInit();

#if defined(PLATFORM_OSX)
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#else
	// On windows, we set OpenGL version to 2.1, to support more hardware
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);
#endif
  int l_iScreenWidth  = GetSystemMetrics(SM_CXSCREEN);
  int l_iScreenHeight = GetSystemMetrics(SM_CYSCREEN);
//  std::cout << "Screen: " << l_iScreenWidth << "x" << l_iScreenHeight << std::endl;
//  std::cout << "Window: " << g_iWindowWidth << "x" << g_iWindowHeight << std::endl;
	window = glfwCreateWindow(SCREEN_WIDTH, SCREEN_HEIGHT, title.c_str(), NULL, NULL);
	if (window == NULL) {
		std::cerr << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		//return -1;
	}
#if 0
  // Place window at center of screen
  int l_iLeft = (l_iScreenWidth/2)-(g_iWindowWidth/2);
  int l_iTop = (l_iScreenHeight/2)-(g_iWindowHeight/2);
#else
  // Place window at bottom right of screen with 1 pixel spacing
  int l_iLeft = l_iScreenWidth-SCREEN_WIDTH-1;
  int l_iTop = l_iScreenHeight-SCREEN_HEIGHT-1;
  RECT rect;
  HWND taskBar = FindWindow("Shell_traywnd", nullptr);
  if (taskBar && GetWindowRect(taskBar, &rect)) {
    l_iTop = l_iTop-(rect.bottom-rect.top);
  }
#endif
//  std::cout << "Position: " << l_iLeft << "x" << l_iTop << std::endl;
  glfwSetWindowMonitor(window, nullptr, l_iLeft, l_iTop, SCREEN_WIDTH, SCREEN_HEIGHT, GLFW_DONT_CARE);

	glfwMakeContextCurrent(window);

	//Modify point size
	glPointSize(10);

	//Modify line thickness
	glLineWidth(3);

	//Disable mouse cursor
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// Initialize GLEW
	glewExperimental = true; // Needed for core profile
	if (glewInit() != GLEW_OK) {
		std::cerr << "Failed to create GLEW" << std::endl;
		glfwTerminate();
		//return -1;
	}
}

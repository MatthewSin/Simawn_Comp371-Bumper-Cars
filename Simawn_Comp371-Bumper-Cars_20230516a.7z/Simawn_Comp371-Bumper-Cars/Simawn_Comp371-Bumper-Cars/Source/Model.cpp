//
// COMP 371 Assignment Framework
//
// Created by Nicolas Bergeron on 8/7/14.
// Updated by Gary Chang on 14/1/15
//
// Copyright (c) 2014-2019 Concordia University. All rights reserved.
//

#include "Model.h"


using namespace std;
using namespace glm;

Model::Model() :	mPosition(0.0f, 0.0f, 0.0f), 
					mScaling(1.0f, 1.0f, 1.0f), 
					mRotationAxis(0.0f, 1.0f, 0.0f),
					mRotationAngleInDegrees(0.0f)
{}

Model::~Model() {
	//glDeleteVertexArrays(1, &VAO);
	//glDeleteBuffers(1, &vertices_VBO);
	//glDeleteBuffers(1, &normals_VBO);
	//glDeleteBuffers(1, &uvs_VBO);
	//glDeleteBuffers(1, &EBO);
}

void Model::Update(float dt) {}

void Model::Draw() {}

glm::mat4 Model::GetWorldMatrix() const {
	mat4 worldMatrix(1.0f);

	mat4 t = glm::translate(mat4(1.0f), mPosition);
	mat4 r = glm::rotate(mat4(1.0f), glm::radians(mRotationAngleInDegrees), mRotationAxis);
	mat4 s = glm::scale(mat4(1.0f), mScaling);
	worldMatrix = t * r * s;

	return worldMatrix;
}

void Model::SetPosition(glm::vec3 position) {
	mPosition = position;
}

void Model::SetScaling(glm::vec3 scaling) {
	mScaling = scaling;
}

void Model::SetRotation(glm::vec3 axis, float angleDegrees) {
	mRotationAxis = axis;
	mRotationAngleInDegrees = angleDegrees;
}

GLuint Model::setupMeshEBO(objl::Mesh mesh) {
	vector<int> vertexIndices; //The contiguous sets of three indices of vertices, normals and UVs, used to make a triangle
	
	vector<glm::vec3> vertices;
	vector<glm::vec3> normals;
	vector<glm::vec2> UVs;

	for (int i = 0; i < mesh.Vertices.size(); i++) {
		vertices.push_back(vec3(mesh.Vertices[i].Position.X, mesh.Vertices[i].Position.Y, mesh.Vertices[i].Position.Z));
		normals.push_back(vec3(mesh.Vertices[i].Normal.X, mesh.Vertices[i].Normal.Y, mesh.Vertices[i].Normal.Z));
		UVs.push_back(vec2(mesh.Vertices[i].TextureCoordinate.X, mesh.Vertices[i].TextureCoordinate.Y));
	}

	for (int i = 0; i < mesh.Indices.size(); i++) {
		vertexIndices.push_back(mesh.Indices[i]);
	}
	
	
	

	//read the vertices from the cube.obj file
	//We won't be needing the normals or UVs for this program
	//loadOBJ2(path.c_str(), vertexIndices, vertices, normals, UVs);

	
	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO); //Becomes active VAO
							// Bind the Vertex Array Object first, then bind and set vertex buffer(s) and attribute pointer(s).

							//Vertex VBO setup
	
	glGenBuffers(1, &vertices_VBO);
	glBindBuffer(GL_ARRAY_BUFFER, vertices_VBO);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(glm::vec3), &vertices.front(), GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	//Normals VBO setup
	
	glGenBuffers(1, &normals_VBO);
	glBindBuffer(GL_ARRAY_BUFFER, normals_VBO);
	glBufferData(GL_ARRAY_BUFFER, normals.size() * sizeof(glm::vec3), &normals.front(), GL_STATIC_DRAW);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(1);

	//UVs VBO setup
	
	glGenBuffers(1, &uvs_VBO);
	glBindBuffer(GL_ARRAY_BUFFER, uvs_VBO);
	glBufferData(GL_ARRAY_BUFFER, UVs.size() * sizeof(glm::vec2), &UVs.front(), GL_STATIC_DRAW);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(2);

	//EBO setup
	
	glGenBuffers(1, &EBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, vertexIndices.size() * sizeof(int), &vertexIndices.front(), GL_STATIC_DRAW);

	glBindVertexArray(0); // Unbind VAO (it's always a good thing to unbind any buffer/array to prevent strange bugs), remember: do NOT unbind the EBO, keep it bound to this VAO
	//vertexCount = vertexIndices.size();
	return VAO;
}

vector<objl::Mesh> Model::loadObj(string path) {
	objl::Loader Loader;
	bool loadout = Loader.LoadFile(path);
	if (loadout) return Loader.LoadedMeshes;
	else {
		cout << "Error loading obj" << endl;
	}
}

/*
// Simawn_Comp371-Bumper-Cars.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

int main()
{
    std::cout << "Hello World!\n";
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
*/

/*
Credits:
- Initial setup from COMP 371 lab code
- Tutorial code from https://learnopengl.com/ and https://www.opengl-tutorial.org/
*/

#ifdef NDEBUG
#include <Windows.h>
#endif

//#define GLEW_STATIC 1
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/rotate_vector.hpp>
#include <glm/common.hpp>
//#include <FreeImageIO.h>
#include <iostream>
#include <list>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>

#include "Shaders.h"
#include "Setup.h"
#include "IO.h"
#include "Renderer.h"
#include "CameraThird.h"
#include "CameraFirst.h"

using namespace glm;
using namespace std;

int main(int argc, char*argv[])
{

#ifdef NDEBUG
  ShowWindow(GetConsoleWindow(), SW_HIDE); //SW_RESTORE to bring back
#endif

	srand(time(0));
	Setup setup = Setup::getInstance(600, 400, "Bumper Cars");
	IO IO = IO::getInstance();
	Shaders shaders = Shaders::getInstance();
	Renderer renderer = Renderer::getInstance();
	
	CameraThird cameraThird = CameraThird::getInstance(vec3(0, 50, 40), vec3(0,0,0), vec3(0.0f, 1.0f, 0.0f));
	CameraFirst cameraFirst = CameraFirst::getInstance(vec3(0.0f), vec3(0.0f), vec3(0.0f, 1.0f, 0.0f));

	//Bumper car where the first person camera will follow
	ModelBumperCar* cameraBumperCar = ModelBumperCar::bumperCarList.back();
	
	const double MAX_FPS = 60.0;
	const double MAX_PERIOD = 1.0 / MAX_FPS;
	double lastTime = 0.0;

    while(!glfwWindowShouldClose(Setup::window)) {
		double t = glfwGetTime();
		double dt = t - lastTime;
		if (dt >= MAX_PERIOD) {
			lastTime = t;
			IO.updateMousePosition();
			renderer.updateTick();

			mat4 projMatrix;
			mat4 viewMatrix;

			if (!IO::isFirstCamera) {
				cameraThird.updateInput();
				projMatrix = cameraThird.getProjMatrix();
				viewMatrix = cameraThird.getViewMatrix();
			} else {
				cameraFirst.updateInput(cameraBumperCar);
				projMatrix = cameraFirst.getProjMatrix();
				viewMatrix = cameraFirst.getViewMatrix();
			}

			renderer.setProjectionMatrix(Shaders::currentShaderProgram, projMatrix);
			renderer.setViewMatrix(Shaders::currentShaderProgram, viewMatrix);

			renderer.renderScene();
			IO.processInputs();
		}
    }

    glfwTerminate();
    
	return 0;
}

